package edu.stevens.cs522.chat.oneway.server.managers;

/**
 * Created by Rafael on 2/21/2016.
 */
public interface IContinue<T> {
    public void kontinue(T value);
}
